import { Component } from '@angular/core';

@Component({
    selector: 'app-background-leaves',
    imports: [],
    templateUrl: './background-leaves.component.html',
    standalone: true,
    styleUrl: './background-leaves.component.css'
})
export class BackgroundLeavesComponent {

}
